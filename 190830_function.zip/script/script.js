var w;
function chk(){
    w = document.getElementById("num").value;
}

function sizer(){
    document.getElementById("box").style.width = w+"px";
    document.getElementById("box").style.height = w+"px";
}

document.getElementById("btn").onclick = function(){
    chk();
    sizer();
}

var name = window.prompt("이름이 뭐에요?");
var adult = window.confirm("만 19세 이상입니까?");

if(adult){
   window.alert(name + "님 안녕하세요");
}else{
   window.alert("훗 애송이 아직 10년은 이르다.");
}
    























